<?php
require 'konversiSuhu.php';

$dataKonversiSuhu1 = new KonversiSuhu("Celcius", 123, "Fahrenheit");
$dataKonversiSuhu2 = new KonversiSuhu("Fahrenheit", 244, "Celcius");
$dataKonversiSuhu3 = new KonversiSuhu("Celcius", 56, "Rheamur");
$dataKonversiSuhu4 = new KonversiSuhu("Rheamur", 50, "Celcius");


$dataKonversiSuhu1->cetak();
$dataKonversiSuhu2->cetak();
$dataKonversiSuhu3->cetak();
$dataKonversiSuhu4->cetak();



?>